# CyberSec Academy 🛡️

Website edukasi keamanan siber berbahasa Indonesia. Dibuat dengan Vite + JavaScript murni, tanpa login dan tanpa backend.

## Fitur
- Materi cyber security untuk pemula
- Kuis interaktif dengan skor
- Tools lokal: generator password, pengukur kekuatan password (tidak mengirim data ke server), dan pemeriksa header keamanan berbasis input URL
- Tantangan CTF pemula
- Progres belajar tersimpan di `localStorage`
- Desain neon gelap yang responsif untuk HP dan desktop

## Jalankan secara lokal
Butuh Node.js versi LTS yang didukung Vite.

```bash
npm install
npm run dev
```

Buka URL lokal yang ditampilkan oleh Vite.

## Build untuk produksi
```bash
npm run build
npm run preview
```

## Deploy ke GitHub + Vercel
1. Buat repository baru di GitHub.
2. Unggah semua file proyek ini ke repository (jangan unggah `node_modules` atau `dist`).
3. Buka [Vercel](https://vercel.com/) lalu pilih **Add New → Project**.
4. Import repository GitHub tersebut.
5. Vercel biasanya mendeteksi Vite otomatis. Pastikan:
   - Framework Preset: `Vite`
   - Build Command: `npm run build`
   - Output Directory: `dist`
6. Klik **Deploy**. Setiap push baru ke branch yang terhubung akan memicu deployment baru.

## Catatan keamanan & privasi
- Tidak ada login atau database. Progres disimpan di browser perangkat pengguna.
- Generator dan pengukur password berjalan di browser. Jangan pernah memasukkan password asli yang sedang digunakan ke demo online.
- Pemeriksa header mencoba membaca header HTTP dari URL yang dimasukkan melalui browser. Banyak situs memblokir pembacaan lintas-origin (CORS); jika gagal, tampilkan instruksi manual. Ini bukan pemindai kerentanan menyeluruh.
- Tools hanya untuk pembelajaran dan domain yang berhak Anda periksa.
- CTF adalah teka-teki lokal; tidak melakukan serangan ke sistem sungguhan.

## Struktur
```text
.
├── index.html
├── package.json
├── vercel.json
├── README.md
└── src/
    ├── main.js
    └── style.css
```
