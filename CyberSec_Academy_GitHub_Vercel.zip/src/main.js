import "./style.css";

const $ = (selector, parent = document) => parent.querySelector(selector);
const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];

const lessons = [
  {
    id: "basics",
    level: "DASAR",
    time: "5 menit",
    title: "Fondasi keamanan siber",
    icon: "◈",
    intro: "Kenali apa yang sebenarnya dilindungi dan mengapa kebiasaan kecil punya dampak besar.",
    body: [
      ["Apa itu cyber security?", "Praktik melindungi perangkat, akun, jaringan, aplikasi, dan data dari akses tanpa izin, penyalahgunaan, kerusakan, atau pencurian."],
      ["Tiga tujuan utama", "Kerahasiaan: hanya pihak berhak yang dapat membaca data. Integritas: data tidak berubah tanpa izin. Ketersediaan: sistem tetap bisa digunakan ketika diperlukan."],
      ["Mulai dari hal sederhana", "Gunakan password unik, aktifkan MFA, pasang pembaruan, buat cadangan data, dan periksa sebelum mengeklik tautan."],
    ],
    takeaway: "Keamanan bukan satu aplikasi ajaib—keamanan adalah lapisan kebiasaan."
  },
  {
    id: "phishing",
    level: "DASAR",
    time: "7 menit",
    title: "Mengenali phishing",
    icon: "⌁",
    intro: "Penipuan digital sering menyerang perhatian dan emosi, bukan kecanggihan teknis.",
    body: [
      ["Tanda yang patut dicurigai", "Pesan mendesak, hadiah yang tidak diminta, alamat pengirim aneh, domain tiruan, lampiran tak terduga, atau permintaan OTP."],
      ["Cara memverifikasi", "Jangan gunakan tautan dari pesan yang mencurigakan. Buka aplikasi resmi secara manual atau hubungi pengirim melalui kanal lain yang sudah dikenal."],
      ["Jika terlanjur mengeklik", "Jangan masukkan data. Tutup halaman, jalankan pembaruan dan pemindaian perangkat, lalu ganti kredensial dari perangkat tepercaya jika data sudah diberikan."],
    ],
    takeaway: "Berhenti sebentar, periksa alamat lengkap, lalu verifikasi lewat jalur resmi."
  },
  {
    id: "passwords",
    level: "DASAR",
    time: "6 menit",
    title: "Password, passkey, dan MFA",
    icon: "⌘",
    intro: "Buat pembobolan lebih sulit dengan kredensial yang unik dan lapisan verifikasi tambahan.",
    body: [
      ["Password yang lebih kuat", "Utamakan frasa panjang yang unik. Jangan memakai ulang password, nama, tanggal lahir, atau pola mudah ditebak."],
      ["Password manager", "Pengelola password membantu membuat dan menyimpan password unik. Lindungi akun manager dengan password utama yang kuat dan MFA."],
      ["MFA dan passkey", "Aktifkan autentikasi multifaktor. Passkey atau aplikasi autentikator biasanya lebih tahan phishing daripada kode SMS, jika tersedia."],
    ],
    takeaway: "Jangan pernah membagikan OTP, recovery code, atau menyetujui login yang tidak Anda mulai."
  },
  {
    id: "devices",
    level: "PRAKTIK",
    time: "8 menit",
    title: "Mengamankan perangkat",
    icon: "▣",
    intro: "HP dan laptop adalah pintu ke banyak akun—rawat keduanya seperti dompet digital.",
    body: [
      ["Pembaruan", "Perbarui sistem operasi, browser, dan aplikasi. Pembaruan sering menutup celah keamanan yang sudah diketahui."],
      ["Izin aplikasi", "Periksa izin kamera, mikrofon, lokasi, kontak, dan aksesibilitas. Cabut izin yang tidak masuk akal untuk fungsi aplikasi."],
      ["Cadangan dan pemulihan", "Simpan cadangan penting di lokasi terpisah. Pastikan Anda tahu cara memulihkan akun jika perangkat hilang."],
    ],
    takeaway: "Instal aplikasi dari sumber resmi dan hapus aplikasi yang tidak lagi dipercaya."
  },
  {
    id: "web",
    level: "MENENGAH",
    time: "10 menit",
    title: "Keamanan website dan API",
    icon: "⌘",
    intro: "Developer perlu menganggap semua input sebagai data yang belum tepercaya.",
    body: [
      ["Validasi input", "Validasi format dan ukuran input di server. Gunakan query database terparameter, bukan menyusun query dari teks pengguna."],
      ["Rahasia dan konfigurasi", "Jangan menaruh API key, token bot, atau password di frontend maupun repository publik. Gunakan environment variables atau secret manager."],
      ["Hak akses minimum", "Berikan izin sesedikit mungkin. Gunakan HTTPS, perbarui dependensi, lindungi sesi, dan catat error tanpa membocorkan rahasia."],
    ],
    takeaway: "Uji hanya aplikasi sendiri atau sistem yang secara jelas memberi izin."
  },
  {
    id: "incident",
    level: "PRAKTIK",
    time: "6 menit",
    title: "Saat akun diduga diretas",
    icon: "⚠",
    intro: "Fokus pada pemulihan, bukan menyalahkan diri sendiri.",
    body: [
      ["Urutan prioritas", "Amankan email utama terlebih dahulu, lalu ganti password unik akun terdampak dan akun lain yang memakai password sama."],
      ["Cabut akses", "Keluar dari semua sesi yang tidak dikenal, cabut aplikasi pihak ketiga mencurigakan, dan periksa email serta nomor pemulihan."],
      ["Simpan bukti", "Catat waktu, simpan tangkapan layar, dan hubungi dukungan resmi. Jika menyangkut transaksi, hubungi penyedia layanan keuangan segera."],
    ],
    takeaway: "Gunakan perangkat tepercaya dan kanal resmi saat melakukan pemulihan."
  }
];

const quiz = [
  {
    q: "Kamu menerima pesan yang mengancam akun akan ditutup dalam 10 menit dan menyertakan tautan.",
    options: ["Klik cepat supaya akun aman", "Buka aplikasi resmi secara manual dan periksa notifikasi", "Teruskan ke semua teman"],
    answer: 1,
    explain: "Tekanan waktu adalah trik umum. Verifikasi lewat aplikasi atau situs resmi yang dibuka sendiri."
  },
  {
    q: "Password akun email dan game sebaiknya…",
    options: ["Sama agar mudah diingat", "Berbeda dan unik untuk tiap akun", "Menggunakan tanggal lahir"],
    answer: 1,
    explain: "Password unik membatasi dampak jika salah satu layanan mengalami kebocoran."
  },
  {
    q: "Seseorang yang mengaku admin meminta kode OTP. Apa tindakan aman?",
    options: ["Kirim jika logonya meyakinkan", "Jangan bagikan kode dan hubungi kanal resmi", "Posting kode di grup bantuan"],
    answer: 1,
    explain: "OTP dan recovery code bersifat rahasia. Petugas resmi tidak perlu meminta kode tersebut."
  },
  {
    q: "Di mana sebaiknya API key aplikasi web disimpan?",
    options: ["Di JavaScript frontend agar praktis", "Di repository publik", "Di server, menggunakan environment variable atau secret manager"],
    answer: 2,
    explain: "Kode frontend dapat dilihat pengguna. Rahasia harus disimpan di sisi server dan tidak di-commit."
  },
  {
    q: "Kamu menemukan APK tak dikenal dari chat grup.",
    options: ["Instal untuk melihat isinya", "Jangan instal dan verifikasi melalui jalur lain", "Matikan pembaruan keamanan"],
    answer: 1,
    explain: "File aplikasi tak dikenal dapat meminta izin berlebihan atau mengandung malware."
  }
];

const ctfChallenges = [
  {
    id: "ctf1", tag: "OSINT MINI", title: "Domain yang janggal",
    prompt: 'Pesan mengarah ke <code>https://bank-aman.example-login.test</code>. Apa yang harus diperiksa lebih dulu?',
    hint: "Cari nama host utama sebelum garis miring pertama setelah https://.",
    accepted: ["domain", "alamat domain", "host", "domain utama", "periksa domain"],
    solution: "Periksa domain/host secara teliti dan bandingkan dengan domain resmi yang Anda ketik sendiri. Teks tautan bisa menipu."
  },
  {
    id: "ctf2", tag: "PASSWORD HYGIENE", title: "Kebiasaan yang berisiko",
    prompt: "Satu password dipakai untuk email, game, dan media sosial. Sebutkan perbaikan utamanya.",
    hint: "Bayangkan jika satu layanan bocor, akun apa saja yang ikut terancam?",
    accepted: ["password unik", "gunakan password unik", "beda password", "password berbeda", "password manager"],
    solution: "Gunakan password unik untuk tiap akun dan pertimbangkan password manager serta MFA."
  },
  {
    id: "ctf3", tag: "INCIDENT RESPONSE", title: "Akun menunjukkan login asing",
    prompt: "Sebutkan langkah prioritas pertama yang masuk akal jika akun penting dicurigai diambil alih.",
    hint: "Akun email sering dipakai untuk memulihkan akun lain.",
    accepted: ["amankan email", "amankan akun email", "ganti password", "keluar dari sesi", "amankan email utama"],
    solution: "Gunakan perangkat tepercaya untuk mengamankan email utama, ganti password yang terdampak, cabut sesi asing, dan aktifkan MFA."
  }
];

const state = {
  page: "overview",
  completed: new Set(JSON.parse(localStorage.getItem("csa-completed") || "[]")),
  quizAnswers: {},
  quizSubmitted: false,
  solved: new Set(JSON.parse(localStorage.getItem("csa-solved") || "[]")),
};

const icon = (name) => ({ overview:"◫", lessons:"▤", quiz:"✳", tools:"⌘", ctf:"⌁" }[name] || "◈");

function saveProgress() {
  localStorage.setItem("csa-completed", JSON.stringify([...state.completed]));
  localStorage.setItem("csa-solved", JSON.stringify([...state.solved]));
}

function progressPercent() {
  const total = lessons.length + ctfChallenges.length;
  return Math.round(((state.completed.size + state.solved.size) / total) * 100);
}

function shell() {
  $("#app").innerHTML = `
    <div class="app-shell">
      <aside class="sidebar">
        <a class="brand" href="#" data-page="overview" aria-label="CyberSec Academy beranda">
          <span class="brand-mark">⌁</span><span>CYBER<span class="brand-accent">SEC</span><small>ACADEMY / LEARN TO DEFEND</small></span>
        </a>
        <div class="side-label">LEARNING SPACE</div>
        <nav class="nav-list" aria-label="Navigasi utama">
          ${navItem("overview","Overview","◫")}
          ${navItem("lessons","Materi belajar","▤")}
          ${navItem("quiz","Kuis interaktif","✳")}
          ${navItem("tools","Cyber tools","⌘")}
          ${navItem("ctf","CTF challenge","⌁")}
        </nav>
        <div class="sidebar-bottom">
          <div class="mini-status"><span class="pulse"></span> SYSTEM STATUS <b>ONLINE</b></div>
          <p>Belajar dengan etis.<br/>Berlatih di lab yang aman.</p>
          <div class="side-version">ACADEMY BUILD 1.0.0</div>
        </div>
      </aside>
      <main class="main">
        <header class="topbar">
          <button class="mobile-menu" id="mobileMenu" aria-label="Buka navigasi">☰</button>
          <div class="breadcrumb"><span>ACADEMY</span><b>/</b><strong id="crumb">OVERVIEW</strong></div>
          <div class="top-right"><span class="online-dot"></span><span>LEARNING MODE</span><div class="avatar">CS</div></div>
        </header>
        <div class="content" id="view"></div>
        <footer>CYBERSEC ACADEMY <span>•</span> Belajar. Lindungi. Ulangi. <span class="footer-right">Dibuat untuk edukasi keamanan siber</span></footer>
      </main>
    </div>`;
  $("#mobileMenu").addEventListener("click", () => $(".sidebar").classList.toggle("open"));
  $$("[data-page]").forEach(el => el.addEventListener("click", e => {
    e.preventDefault();
    navigate(el.dataset.page);
  }));
}

function navItem(id, label, symbol) {
  return `<button class="nav-item ${state.page === id ? "active" : ""}" data-page="${id}"><span>${symbol}</span>${label}<i>↗</i></button>`;
}

function navigate(page) {
  state.page = page;
  $(".sidebar")?.classList.remove("open");
  render();
  $$(".nav-item").forEach(el => el.classList.toggle("active", el.dataset.page === page));
}

function render() {
  const titles = { overview:"OVERVIEW", lessons:"LEARNING MODULES", quiz:"KNOWLEDGE CHECK", tools:"SECURITY TOOLKIT", ctf:"CHALLENGE ZONE" };
  $("#crumb").textContent = titles[state.page] || "OVERVIEW";
  const view = $("#view");
  if (state.page === "overview") view.innerHTML = renderOverview();
  if (state.page === "lessons") view.innerHTML = renderLessons();
  if (state.page === "quiz") view.innerHTML = renderQuiz();
  if (state.page === "tools") view.innerHTML = renderTools();
  if (state.page === "ctf") view.innerHTML = renderCTF();
  bindView();
}

function renderOverview() {
  const pct = progressPercent();
  const doneLessons = state.completed.size;
  return `
    <section class="hero">
      <div class="hero-grid"></div><div class="hero-copy">
        <div class="eyebrow"><span class="pulse"></span> YOUR CYBER JOURNEY STARTS HERE</div>
        <h1>Learn to <span>defend.</span><br/>Think like a guardian.</h1>
        <p>Pelajari keamanan siber lewat materi ringkas, kuis, tools edukatif, dan challenge yang aman untuk pemula.</p>
        <div class="hero-actions"><button class="btn btn-primary" data-go="lessons">Mulai belajar <span>↗</span></button><button class="btn btn-ghost" data-go="ctf">Coba challenge <span>⌁</span></button></div>
      </div>
      <div class="hero-art" aria-hidden="true"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="shield"><span>⌁</span><small>SECURE<br/>BY DESIGN</small></div><div class="float-tag tag-a">◈ ENCRYPTED</div><div class="float-tag tag-b"><span class="pulse"></span> THREAT AWARENESS</div><div class="crosshair">+</div></div>
      <div class="hero-bottom"><span><b>01</b> LEARN THE BASICS</span><span><b>02</b> PRACTICE SAFELY</span><span><b>03</b> BUILD GOOD HABITS</span></div>
    </section>
    <div class="section-heading"><div><div class="eyebrow">ACADEMY OVERVIEW</div><h2>Dashboard belajar</h2></div><span class="subtle">PROGRES DISIMPAN DI PERANGKAT INI</span></div>
    <section class="stats-grid">
      <article class="stat-card"><div class="stat-icon cyan">▤</div><span>MODUL SELESAI</span><strong>${doneLessons}<small>/${lessons.length}</small></strong><div class="stat-foot">Materi pembelajaran</div></article>
      <article class="stat-card"><div class="stat-icon purple">✳</div><span>SKOR KUIS</span><strong>${state.quizSubmitted ? `${scoreQuiz()}/${quiz.length}` : "—"}</strong><div class="stat-foot">Coba untuk mengukur pemahaman</div></article>
      <article class="stat-card"><div class="stat-icon green">⌁</div><span>CTF TERSELESAIKAN</span><strong>${state.solved.size}<small>/${ctfChallenges.length}</small></strong><div class="stat-foot">Tantangan lokal pemula</div></article>
      <article class="stat-card"><div class="stat-icon orange">◉</div><span>PROGRES TOTAL</span><strong>${pct}<small>%</small></strong><div class="stat-progress"><i style="width:${pct}%"></i></div></article>
    </section>
    <section class="home-grid">
      <div class="panel">
        <div class="panel-heading"><div><div class="eyebrow">RECOMMENDED PATH</div><h3>Jalur belajar pilihan</h3></div><span class="panel-number">01 — 06</span></div>
        ${lessons.slice(0,4).map((l,i)=>`<button class="path-row" data-lesson="${l.id}"><span class="path-num">${String(i+1).padStart(2,"0")}</span><span class="path-icon">${l.icon}</span><span class="path-text"><b>${l.title}</b><small>${l.level} <span>•</span> ${l.time}</small></span><span class="path-check ${state.completed.has(l.id)?"done":""}">${state.completed.has(l.id)?"✓":"↗"}</span></button>`).join("")}
        <button class="text-link" data-go="lessons">Lihat semua materi <span>→</span></button>
      </div>
      <div class="panel mission-panel"><div class="eyebrow">DAILY MISSION</div><div class="mission-symbol">⌘</div><h3>Jadi lebih sulit ditipu.</h3><p>Uji insting keamananmu lewat skenario singkat. Ingat: berhenti, periksa, verifikasi.</p><div class="mission-tags"><span>5 QUESTIONS</span><span>BEGINNER</span></div><button class="btn btn-primary full" data-go="quiz">Mulai kuis <span>↗</span></button><div class="mission-note"><span class="pulse"></span> Tidak perlu akun. Progres tersimpan lokal.</div></div>
    </section>
    <section class="tip-banner"><div class="tip-symbol">✦</div><div><b>SECURITY TIP OF THE DAY</b><p>Aktifkan MFA di email utama. Email sering menjadi kunci pemulihan akun lain.</p></div><span class="tip-id">TIP_001</span></section>`;
}

function renderLessons() {
  return `<div class="page-intro"><div class="eyebrow">KNOWLEDGE BASE / 06 MODULES</div><h1>Materi <span>belajar.</span></h1><p>Mulai dari konsep dasar hingga kebiasaan keamanan untuk developer. Pilih modul, pelajari, lalu tandai selesai.</p></div>
    <div class="lesson-grid">${lessons.map((l,i)=>`<article class="lesson-card"><div class="lesson-card-top"><span class="lesson-icon">${l.icon}</span><span class="lesson-number">MODULE ${String(i+1).padStart(2,"0")}</span><span class="lesson-state ${state.completed.has(l.id)?"complete":""}">${state.completed.has(l.id)?"✓ SELESAI":"○ BELUM SELESAI"}</span></div><div class="lesson-meta"><span>${l.level}</span><span>•</span><span>${l.time}</span></div><h3>${l.title}</h3><p>${l.intro}</p><button class="btn btn-card" data-lesson="${l.id}">${state.completed.has(l.id)?"Buka ulang":"Pelajari modul"} <span>↗</span></button></article>`).join("")}</div>`;
}

function renderLessonDetail(id) {
  const l = lessons.find(x=>x.id===id);
  if (!l) return renderLessons();
  return `<button class="back-link" data-go="lessons">← Kembali ke materi</button><div class="detail-head"><div class="lesson-icon big">${l.icon}</div><div><div class="eyebrow">MODULE / ${l.level} / ${l.time}</div><h1>${l.title}</h1><p>${l.intro}</p></div></div><div class="detail-layout"><article class="panel lesson-content">${l.body.map((b,i)=>`<section class="lesson-section"><div class="section-index">${String(i+1).padStart(2,"0")}</div><div><h3>${b[0]}</h3><p>${b[1]}</p></div></section>`).join("")}<div class="takeaway"><span>✦ KEY TAKEAWAY</span><p>${l.takeaway}</p></div><button class="btn btn-primary" id="completeLesson">${state.completed.has(l.id)?"✓ Modul sudah selesai":"Tandai modul selesai"} <span>→</span></button></article><aside class="panel detail-aside"><div class="eyebrow">YOUR PROGRESS</div><div class="big-progress">${state.completed.has(l.id)?"100%":"0%"}</div><div class="progress-track"><i style="width:${state.completed.has(l.id)?"100":"0"}%"></i></div><p>${state.completed.has(l.id)?"Modul ini sudah kamu selesaikan.":"Selesaikan materi lalu tandai sebagai selesai."}</p><div class="aside-rule"></div><b>Tips belajar</b><p>Catat satu kebiasaan yang bisa langsung kamu terapkan hari ini.</p></aside></div>`;
}

function renderQuiz() {
  return `<div class="page-intro"><div class="eyebrow">KNOWLEDGE CHECK / ${quiz.length} QUESTIONS</div><h1>Uji <span>instingmu.</span></h1><p>Pilih respons paling aman untuk setiap skenario. Ini latihan kebiasaan, bukan ujian sertifikasi.</p></div>
    <div class="quiz-layout"><div class="quiz-main">${quiz.map((q,i)=>`<article class="panel quiz-question"><div class="question-top"><span>QUESTION ${String(i+1).padStart(2,"0")}</span><span>${i+1} / ${quiz.length}</span></div><h3>${q.q}</h3><div class="quiz-options">${q.options.map((o,j)=>`<label class="quiz-option ${state.quizSubmitted&&j===q.answer?"correct":state.quizSubmitted&&state.quizAnswers[i]===j&&j!==q.answer?"wrong":""}"><input type="radio" name="q${i}" value="${j}" ${state.quizAnswers[i]===j?"checked":""} ${state.quizSubmitted?"disabled":""}/><span class="option-letter">${String.fromCharCode(65+j)}</span><span>${o}</span>${state.quizSubmitted&&j===q.answer?'<b class="answer-mark">✓</b>':""}</label>`).join("")}</div>${state.quizSubmitted?`<div class="explanation"><b>KENAPA?</b><p>${q.explain}</p></div>`:""}</article>`).join("")}
    <div class="quiz-actions">${state.quizSubmitted?`<button class="btn btn-ghost" id="resetQuiz">↻ Ulangi kuis</button><div class="result-pill">SKOR: ${scoreQuiz()} / ${quiz.length}</div>`:`<button class="btn btn-primary" id="submitQuiz">Periksa jawaban <span>→</span></button><span class="subtle">Jawab semua ${quiz.length} pertanyaan</span>`}</div></div>
    <aside class="panel quiz-aside"><div class="eyebrow">QUIZ PROGRESS</div><div class="quiz-score">${state.quizSubmitted?Math.round(scoreQuiz()/quiz.length*100):"—"}<small>${state.quizSubmitted?"%":"SCORE"}</small></div><div class="progress-track"><i style="width:${state.quizSubmitted?scoreQuiz()/quiz.length*100: Object.keys(state.quizAnswers).length/quiz.length*100}%"></i></div><p>${Object.keys(state.quizAnswers).length} dari ${quiz.length} pertanyaan dijawab.</p><div class="aside-rule"></div><b>Ingat</b><p>Kalau ragu, jangan buru-buru. Verifikasi lewat sumber resmi.</p></aside></div>`;
}

function scoreQuiz() {
  return quiz.reduce((n,q,i)=>n+(state.quizAnswers[i]===q.answer?1:0),0);
}

function renderTools() {
  return `<div class="page-intro"><div class="eyebrow">LOCAL UTILITIES / CLIENT-SIDE</div><h1>Security <span>toolkit.</span></h1><p>Alat bantu edukatif yang berjalan di browser. Jangan masukkan password asli yang sedang kamu gunakan.</p></div>
  <div class="tools-grid">
    <article class="panel tool-card"><div class="tool-head"><span class="tool-icon">⌘</span><span class="tool-label">TOOL_01 / GENERATOR</span></div><h3>Generator password</h3><p>Buat password acak untuk latihan. Hasil dibuat di browser dan tidak dikirim ke server.</p><div class="field-row"><label for="pwLength">Panjang</label><input id="pwLength" type="range" min="12" max="32" value="18"/><output id="pwLengthOut">18 karakter</output></div><div class="check-row"><label><input id="pwSymbols" type="checkbox" checked/> Sertakan simbol</label></div><div class="generated-output"><code id="generatedPassword">Tekan tombol generate</code><button class="icon-button" id="copyPassword" aria-label="Salin password" title="Salin">⧉</button></div><button class="btn btn-primary full" id="generatePassword">Generate password <span>↻</span></button><div class="tool-feedback" id="pwFeedback" aria-live="polite"></div></article>
    <article class="panel tool-card"><div class="tool-head"><span class="tool-icon purple">◉</span><span class="tool-label">TOOL_02 / PASSWORD CHECK</span></div><h3>Periksa kekuatan contoh</h3><p>Masukkan contoh fiktif untuk melihat indikator sederhana. Jangan gunakan password sungguhan.</p><label class="field-label" for="strengthInput">Password contoh</label><div class="input-with-button"><input id="strengthInput" type="password" placeholder="Ketik contoh fiktif..."/><button id="toggleStrength" class="icon-button" aria-label="Tampilkan password">◉</button></div><div class="strength-track"><i id="strengthBar"></i></div><div class="strength-caption"><span id="strengthLabel">Belum diperiksa</span><span id="strengthBits">—</span></div><ul class="check-list" id="strengthChecks"><li>Panjang minimal 12 karakter</li><li>Kombinasi karakter</li><li>Tidak mudah ditebak</li></ul><div class="tool-feedback">Pemeriksaan ini edukatif dan bukan pengukur keamanan sempurna.</div></article>
    <article class="panel tool-card wide-tool"><div class="tool-head"><span class="tool-icon green">⌁</span><span class="tool-label">TOOL_03 / WEB HYGIENE</span></div><h3>Pemeriksa security header</h3><p>Masukkan domain yang kamu miliki atau berhak uji. Browser mungkin tidak bisa membaca header lintas-origin karena aturan CORS; jika gagal, gunakan pemeriksaan manual.</p><form id="headerForm"><label class="field-label" for="headerUrl">URL website</label><div class="url-form"><input id="headerUrl" type="url" placeholder="https://example.com" required/><button class="btn btn-primary" type="submit">Periksa <span>↗</span></button></div></form><div id="headerResults" class="header-results"><div class="empty-result">Hasil pemeriksaan akan muncul di sini.</div></div><div class="tool-feedback">Tidak melakukan pemindaian celah keamanan. Hanya mencoba membaca header respons yang dapat diakses browser.</div></article>
  </div>`;
}

function renderCTF() {
  return `<div class="page-intro"><div class="eyebrow">SAFE PRACTICE / BEGINNER LAB</div><h1>Challenge <span>zone.</span></h1><p>Latihan berbasis skenario lokal. Tidak ada target sungguhan, eksploit, atau pemindaian jaringan.</p></div>
  <div class="ctf-banner"><div><div class="eyebrow">TRAINING SIMULATION</div><h2>Think. Check. Protect.</h2><p>Selesaikan teka-teki untuk mengasah kebiasaan keamanan yang baik.</p></div><div class="ctf-total"><strong>${state.solved.size.toString().padStart(2,"0")}<small>/${ctfChallenges.length.toString().padStart(2,"0")}</small></strong><span>COMPLETED</span></div></div>
  <div class="ctf-grid">${ctfChallenges.map((c,i)=>`<article class="panel ctf-card"><div class="ctf-card-top"><span class="ctf-index">CHALLENGE 0${i+1}</span><span class="ctf-status ${state.solved.has(c.id)?"solved":""}">${state.solved.has(c.id)?"✓ SOLVED":"● AVAILABLE"}</span></div><span class="ctf-tag">${c.tag}</span><h3>${c.title}</h3><div class="ctf-prompt">${c.prompt}</div><label class="field-label" for="answer-${c.id}">Jawabanmu</label><input id="answer-${c.id}" class="ctf-answer" placeholder="Ketik jawaban singkat..." ${state.solved.has(c.id)?"disabled":""}/><div class="ctf-buttons"><button class="btn btn-primary" data-check-ctf="${c.id}" ${state.solved.has(c.id)?"disabled":""}>Kirim jawaban <span>→</span></button><button class="btn btn-ghost" data-hint="${c.id}">Petunjuk</button></div><div class="ctf-feedback" id="feedback-${c.id}" aria-live="polite">${state.solved.has(c.id)?`<b>✓ Terselesaikan</b><p>${c.solution}</p>`:""}</div></article>`).join("")}</div>`;
}

function bindView() {
  $$("[data-go]").forEach(el=>el.addEventListener("click",()=>navigate(el.dataset.go)));
  $$("[data-lesson]").forEach(el=>el.addEventListener("click",()=>{
    const id=el.dataset.lesson;
    $("#view").innerHTML=renderLessonDetail(id);
    bindDetail(id);
  }));
  if ($("#submitQuiz")) $("#submitQuiz").addEventListener("click",()=>{
    if(Object.keys(state.quizAnswers).length!==quiz.length) {
      alert("Jawab semua pertanyaan dulu, ya.");
      return;
    }
    state.quizSubmitted=true; render();
  });
  if ($("#resetQuiz")) $("#resetQuiz").addEventListener("click",()=>{
    state.quizAnswers={}; state.quizSubmitted=false; render();
  });
  $$('input[type="radio"][name^="q"]').forEach(input=>input.addEventListener("change",()=>{
    state.quizAnswers[Number(input.name.slice(1))]=Number(input.value);
    const answered=Object.keys(state.quizAnswers).length;
    const p=$(".quiz-aside .progress-track i");
    if(p) p.style.width=`${answered/quiz.length*100}%`;
    const text=$(".quiz-aside p");
    if(text) text.textContent=`${answered} dari ${quiz.length} pertanyaan dijawab.`;
  }));
  if ($("#pwLength")) {
    $("#pwLength").addEventListener("input",()=>$("#pwLengthOut").textContent=`${$("#pwLength").value} karakter`);
    $("#generatePassword").addEventListener("click",generatePassword);
    $("#copyPassword").addEventListener("click",async()=>{
      const value=$("#generatedPassword").textContent;
      if(!value || value==="Tekan tombol generate") return;
      try { await navigator.clipboard.writeText(value); $("#pwFeedback").textContent="Password berhasil disalin."; }
      catch { $("#pwFeedback").textContent="Clipboard tidak tersedia. Pilih dan salin teks secara manual."; }
    });
    $("#strengthInput").addEventListener("input",checkStrength);
    $("#toggleStrength").addEventListener("click",()=>$("#strengthInput").type=$("#strengthInput").type==="password"?"text":"password");
    $("#headerForm").addEventListener("submit",checkHeaders);
  }
  $$("[data-hint]").forEach(el=>el.addEventListener("click",()=>{
    const c=ctfChallenges.find(x=>x.id===el.dataset.hint);
    const fb=$(`#feedback-${c.id}`);
    fb.innerHTML=`<b>💡 Petunjuk</b><p>${c.hint}</p>`;
  }));
  $$("[data-check-ctf]").forEach(el=>el.addEventListener("click",()=>{
    const c=ctfChallenges.find(x=>x.id===el.dataset.checkCtf);
    const answer=$(`#answer-${c.id}`).value.trim().toLowerCase();
    const ok=c.accepted.some(a=>answer.includes(a));
    const fb=$(`#feedback-${c.id}`);
    if(ok) {
      state.solved.add(c.id); saveProgress();
      fb.innerHTML=`<b>✓ Challenge terselesaikan!</b><p>${c.solution}</p>`;
      $(`#answer-${c.id}`).disabled=true; el.disabled=true;
      el.textContent="✓ Selesai";
      $(`[data-hint="${c.id}"]`).disabled=true;
      $(".ctf-total strong").innerHTML=`${state.solved.size.toString().padStart(2,"0")}<small>/${ctfChallenges.length.toString().padStart(2,"0")}</small>`;
      $(`.ctf-card:has([data-check-ctf="${c.id}"]) .ctf-status`).classList.add("solved");
      $(`.ctf-card:has([data-check-ctf="${c.id}"]) .ctf-status`).textContent="✓ SOLVED";
    } else {
      fb.innerHTML="<b>Belum tepat—coba lagi.</b><p>Pikirkan prinsip dasar: verifikasi, password unik, dan pemulihan akun.</p>";
    }
  }));
}

function bindDetail(id) {
  $("#completeLesson")?.addEventListener("click",()=>{
    state.completed.add(id); saveProgress(); render();
    $("#view").innerHTML=renderLessonDetail(id); bindDetail(id);
  });
}

function generatePassword() {
  const length=Number($("#pwLength").value);
  const symbols=$("#pwSymbols").checked;
  const sets=["ABCDEFGHJKLMNPQRSTUVWXYZ","abcdefghijkmnopqrstuvwxyz","23456789"];
  if(symbols) sets.push("!@#$%*-_+=");
  const chars=sets.join("");
  const randomInt=max=>{
    const arr=new Uint32Array(1); crypto.getRandomValues(arr);
    return arr[0] % max;
  };
  let result=sets.map(set=>set[randomInt(set.length)]);
  while(result.length<length) result.push(chars[randomInt(chars.length)]);
  for(let i=result.length-1;i>0;i--){const j=randomInt(i+1);[result[i],result[j]]=[result[j],result[i]];}
  $("#generatedPassword").textContent=result.join("");
  $("#pwFeedback").textContent="Dibuat secara lokal di browser. Simpan dengan password manager jika akan digunakan.";
}

function checkStrength() {
  const value=$("#strengthInput").value;
  const checks=[
    {ok:value.length>=12,label:"Panjang minimal 12 karakter"},
    {ok:/[a-z]/.test(value)&&/[A-Z]/.test(value)&&/[0-9]/.test(value),label:"Huruf kecil, besar, dan angka"},
    {ok:/[^A-Za-z0-9]/.test(value),label:"Ada simbol atau pemisah"}
  ];
  const score=checks.filter(x=>x.ok).length+(value.length>=16?1:0);
  const labels=["Sangat lemah","Perlu diperkuat","Cukup","Lebih baik"];
  $("#strengthLabel").textContent=value?labels[Math.min(score,3)]:"Belum diperiksa";
  $("#strengthBits").textContent=value?`${value.length} karakter`:"—";
  $("#strengthBar").style.width=value?`${[15,38,68,100][Math.min(score,3)]}%`:"0%";
  $("#strengthBar").className=score<=1?"weak":score===2?"medium":"strong";
  $("#strengthChecks").innerHTML=checks.map(c=>`<li class="${c.ok?"pass":""}"><span>${c.ok?"✓":"○"}</span>${c.label}</li>`).join("");
}

async function checkHeaders(event) {
  event.preventDefault();
  const out=$("#headerResults");
  let url;
  try {
    url=new URL($("#headerUrl").value);
    if(!["http:","https:"].includes(url.protocol)) throw new Error();
  } catch {
    out.innerHTML='<div class="header-error">Masukkan URL valid yang dimulai dengan http:// atau https://.</div>'; return;
  }
  out.innerHTML='<div class="empty-result"><span class="spinner"></span> Mencoba membaca header yang dapat diakses browser…</div>';
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),7000);
  try {
    const response=await fetch(url.href,{method:"HEAD",mode:"cors",redirect:"follow",signal:controller.signal});
    clearTimeout(timeout);
    const checks=[
      ["Content-Security-Policy",response.headers.get("content-security-policy"),"Membatasi sumber konten yang boleh dimuat."],
      ["Strict-Transport-Security",response.headers.get("strict-transport-security"),"Meminta browser memakai HTTPS untuk koneksi berikutnya."],
      ["X-Content-Type-Options",response.headers.get("x-content-type-options"),"Mencegah tebakan MIME type tertentu."],
      ["Referrer-Policy",response.headers.get("referrer-policy"),"Mengatur informasi referrer yang dikirim."],
      ["Permissions-Policy",response.headers.get("permissions-policy"),"Mengatur akses fitur browser seperti kamera dan mikrofon."]
    ];
    out.innerHTML=`<div class="header-summary">Respons bisa dibaca: <b>${response.status} ${response.statusText||""}</b>. Hasil ini terbatas pada header yang terlihat oleh browser.</div>`+
      checks.map(([name,value,desc])=>`<div class="header-row"><span class="header-state ${value?"present":"missing"}">${value?"TERLIHAT":"TIDAK TERLIHAT"}</span><div><b>${name}</b><p>${desc}</p>${value?`<code>${escapeHtml(value)}</code>`:""}</div></div>`).join("");
  } catch {
    clearTimeout(timeout);
    out.innerHTML=`<div class="header-error"><b>Browser tidak dapat membaca respons.</b><p>Ini sering terjadi karena CORS, kebijakan server, atau jaringan. Bukan bukti bahwa situs rentan.</p><ol><li>Buka DevTools → Network, atau gunakan alat audit resmi.</li><li>Periksa header pada respons dokumen utama.</li><li>Uji hanya domain yang kamu miliki atau berhak periksa.</li></ol></div>`;
  }
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

shell();
render();
